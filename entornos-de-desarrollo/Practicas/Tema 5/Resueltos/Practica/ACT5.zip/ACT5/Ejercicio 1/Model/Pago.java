
import java.util.*;

/**
 * 
 */
public class Pago {

    /**
     * Default constructor
     */
    public Pago() {
    }

    /**
     * 
     */
    public Int importe;

    /**
     * 
     */
    public Int plazos;

}