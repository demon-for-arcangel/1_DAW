
import java.util.*;

/**
 * 
 */
public class Efectivo {

    /**
     * Default constructor
     */
    public Efectivo() {
    }

    /**
     * 
     */
    public void moneda;

}