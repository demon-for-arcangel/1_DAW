
import java.util.*;

/**
 * 
 */
public class Cliente {

    /**
     * Default constructor
     */
    public Cliente() {
    }

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public String direccion;

    /**
     * 
     */
    public Int telefono;

    /**
     * 
     */
    public String correo_electronico;

}