
import java.util.*;

/**
 * 
 */
public class Precios {

    /**
     * Default constructor
     */
    public Precios() {
    }

}