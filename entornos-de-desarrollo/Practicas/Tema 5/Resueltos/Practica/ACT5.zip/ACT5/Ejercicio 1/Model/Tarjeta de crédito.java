
import java.util.*;

/**
 * 
 */
public class Tarjeta de crédito {

    /**
     * Default constructor
     */
    public Tarjeta de crédito() {
    }

    /**
     * 
     */
    public Int fecha caducidad;

    /**
     * 
     */
    public Int numero;

    /**
     * 
     */
    public Tarjeta tipo;

}