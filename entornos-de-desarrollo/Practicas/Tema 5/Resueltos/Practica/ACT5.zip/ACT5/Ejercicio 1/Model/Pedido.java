
import java.util.*;

/**
 * 
 */
public class Pedido {

    /**
     * Default constructor
     */
    public Pedido() {
    }

    /**
     * 
     */
    public String cantidad;

    /**
     * 
     */
    public Int coste total;

}