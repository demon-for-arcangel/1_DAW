
import java.util.*;

/**
 * 
 */
public class Estado pedido {

    /**
     * Default constructor
     */
    public Estado pedido() {
    }

    /**
     * 
     */
    public Bolean pendiente;

    /**
     * 
     */
    public Bolean pagado;

    /**
     * 
     */
    public Bolean procesando;

    /**
     * 
     */
    public Bolean enviado;

    /**
     * 
     */
    public Bolean entregado;

}