
import java.util.*;

/**
 * 
 */
public class Producto {

    /**
     * Default constructor
     */
    public Producto() {
    }

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public Int existencias;

}