
import java.util.*;

/**
 * 
 */
public class Cheque {

    /**
     * Default constructor
     */
    public Cheque() {
    }

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public String entidad bancaria;

}