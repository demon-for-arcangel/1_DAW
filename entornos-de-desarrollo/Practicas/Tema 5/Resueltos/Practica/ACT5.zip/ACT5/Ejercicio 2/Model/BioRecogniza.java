
import java.util.*;

/**
 * 
 */
public class BioRecogniza {

    /**
     * Default constructor
     */
    public BioRecogniza() {
    }

}