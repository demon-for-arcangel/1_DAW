
import java.util.*;

/**
 * 
 */
public class PCB {

    /**
     * Default constructor
     */
    public PCB() {
    }

    /**
     * 
     */
    public String modelo;

    /**
     * 
     */
    public String revision;

    /**
     * 
     */
    public Int anio;

    /**
     * @return
     */
    public String getModelo() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getRevision() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public Int getAnio() {
        // TODO implement here
        return null;
    }

}