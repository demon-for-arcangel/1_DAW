
import java.util.*;

/**
 * 
 */
public class SensorRuta {

    /**
     * Default constructor
     */
    public SensorRuta() {
    }

}