
import java.util.*;

/**
 * 
 */
public class Giroscopio {

    /**
     * Default constructor
     */
    public Giroscopio() {
    }

}