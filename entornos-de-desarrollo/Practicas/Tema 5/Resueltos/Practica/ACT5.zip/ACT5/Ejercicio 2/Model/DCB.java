
import java.util.*;

/**
 * 
 */
public class DCB {

    /**
     * Default constructor
     */
    public DCB() {
    }

    /**
     * 
     */
    public String modelo;

    /**
     * 
     */
    public String revision;

    /**
     * 
     */
    public Int anio;

    /**
     * 
     */
    public BioRecogniza moduloBioRecogniza;

    /**
     * 
     */
    public Acelerometro acelerometro;

    /**
     * 
     */
    public Giroscopio giroscopio;

    /**
     * 
     */
    public SensorRuta sensorRuta;

    /**
     * @return
     */
    public String getModelo() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getRevision() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public Int getAnio() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public BioRecogniza getModuloBioRecogniza() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Acelerometro getAcelerometro() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Giroscopio getGiroscopio() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public SensorRuta getSensorRuta() {
        // TODO implement here
        return null;
    }

}