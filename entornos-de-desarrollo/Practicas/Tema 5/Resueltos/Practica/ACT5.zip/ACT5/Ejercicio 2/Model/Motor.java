
import java.util.*;

/**
 * 
 */
public class Motor {

    /**
     * Default constructor
     */
    public Motor() {
    }

    /**
     * 
     */
    public Int kv;

    /**
     * 
     */
    public String sentidoGiros;

    /**
     * @return
     */
    public Int getkv() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public String getSentidoGiros() {
        // TODO implement here
        return "";
    }

}