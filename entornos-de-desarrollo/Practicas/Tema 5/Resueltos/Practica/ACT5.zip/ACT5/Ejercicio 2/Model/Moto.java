
import java.util.*;

/**
 * 
 */
public class Moto {

    /**
     * Default constructor
     */
    public Moto() {
    }

    /**
     * 
     */
    public Bateria bateria;

    /**
     * 
     */
    public DCB dcb;

    /**
     * 
     */
    public PCB pcb;

    /**
     * 
     */
    public Motor motor;

}