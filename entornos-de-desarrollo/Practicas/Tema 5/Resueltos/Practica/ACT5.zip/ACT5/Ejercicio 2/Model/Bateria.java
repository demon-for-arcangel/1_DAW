
import java.util.*;

/**
 * 
 */
public class Bateria {

    /**
     * Default constructor
     */
    public Bateria() {
    }

    /**
     * 
     */
    public Int duracion;

    /**
     * 
     */
    public Int ciclos;

    /**
     * 
     */
    public Boolean sensor;

    /**
     * @return
     */
    public Int getDuracion() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Int getCiclos() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public Boolean getSensor() {
        // TODO implement here
        return null;
    }

}