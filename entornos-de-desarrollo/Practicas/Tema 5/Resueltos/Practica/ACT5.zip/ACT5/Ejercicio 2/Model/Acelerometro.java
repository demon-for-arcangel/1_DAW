
import java.util.*;

/**
 * 
 */
public class Acelerometro {

    /**
     * Default constructor
     */
    public Acelerometro() {
    }

}