
import java.util.*;

/**
 * 
 */
public class Evento {

    /**
     * Default constructor
     */
    public Evento() {
    }

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public String lugar;

    /**
     * 
     */
    public Int fecha;

    /**
     * 
     */
    public void consultarDisponibilidad() {
        // TODO implement here
    }

    /**
     * 
     */
    public void calcularPrecio() {
        // TODO implement here
    }

    /**
     * 
     */
    public void actualizarAsientos() {
        // TODO implement here
    }

}