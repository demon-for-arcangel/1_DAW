
import java.util.*;

/**
 * 
 */
public class Entrada {

    /**
     * Default constructor
     */
    public Entrada() {
    }

    /**
     * 
     */
    public Int idEntrada;

    /**
     * 
     */
    public Int fechaCompra;

    /**
     * 
     */
    public Double precio;

    /**
     * 
     */
    public Double descuentos;

    /**
     * 
     */
    public String localizador;

    /**
     * 
     */
    public void generarLozalizador() {
        // TODO implement here
    }

}