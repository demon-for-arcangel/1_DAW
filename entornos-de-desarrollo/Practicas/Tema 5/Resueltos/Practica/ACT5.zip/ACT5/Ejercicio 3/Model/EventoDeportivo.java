
import java.util.*;

/**
 * 
 */
public class EventoDeportivo {

    /**
     * Default constructor
     */
    public EventoDeportivo() {
    }

}