
import java.util.*;

/**
 * 
 */
public class Asiento {

    /**
     * Default constructor
     */
    public Asiento() {
    }

    /**
     * 
     */
    public Int idAsiento;

    /**
     * 
     */
    public Int fila;

    /**
     * 
     */
    public Int numAsiento;

    /**
     * 
     */
    public Boolean estado;

    /**
     * 
     */
    public void reservar() {
        // TODO implement here
    }

    /**
     * 
     */
    public void cancelarReserva() {
        // TODO implement here
    }

}