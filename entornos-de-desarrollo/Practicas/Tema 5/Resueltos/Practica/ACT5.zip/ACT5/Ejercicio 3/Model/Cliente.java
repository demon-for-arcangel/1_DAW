
import java.util.*;

/**
 * 
 */
public class Cliente {

    /**
     * Default constructor
     */
    public Cliente() {
    }

    /**
     * 
     */
    public Int idCliente;

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public String dni;

    /**
     * 
     */
    public String tipo;

    /**
     * 
     */
    public void comprarEntrada() {
        // TODO implement here
    }

    /**
     * 
     */
    public void reservarEntrada() {
        // TODO implement here
    }

    /**
     * 
     */
    public void cancelarReserva() {
        // TODO implement here
    }

}