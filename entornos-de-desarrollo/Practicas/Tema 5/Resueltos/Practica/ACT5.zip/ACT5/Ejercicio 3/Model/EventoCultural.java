
import java.util.*;

/**
 * 
 */
public class EventoCultural {

    /**
     * Default constructor
     */
    public EventoCultural() {
    }

}