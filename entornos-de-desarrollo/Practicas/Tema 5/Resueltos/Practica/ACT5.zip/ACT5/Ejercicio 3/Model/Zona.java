
import java.util.*;

/**
 * 
 */
public class Zona {

    /**
     * Default constructor
     */
    public Zona() {
    }

    /**
     * 
     */
    public String nombre;

    /**
     * 
     */
    public Double precio;

    /**
     * 
     */
    public void consultarDisponibilidad() {
        // TODO implement here
    }

    /**
     * 
     */
    public void calcularPrecio() {
        // TODO implement here
    }

}