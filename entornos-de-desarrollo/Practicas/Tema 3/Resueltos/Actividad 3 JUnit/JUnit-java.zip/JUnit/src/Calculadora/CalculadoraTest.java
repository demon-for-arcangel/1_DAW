package Calculadora;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculadoraTest {

	@Test
	void testSumar() {
		double resultado = Calculadora.sumar(2.0, 3.0);
		assertEquals(6.0, resultado, 0.0);
	}
	/* el caso de prueba que estamos realizando es con los valores 2 y 3 
	nosotros esperamos que el resultado sea 5
	*/
}