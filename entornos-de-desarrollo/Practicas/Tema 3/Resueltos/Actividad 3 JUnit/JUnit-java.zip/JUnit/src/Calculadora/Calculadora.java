package Calculadora;
import java.util.Scanner;

public class Calculadora {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;
        double num1, num2, resultado;
        do {
            System.out.println("\nCALCULADORA\n");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicación");
            System.out.println("4. División");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("\nSUMA\n");
                    num1 = ingresarNumero(sc, "Ingrese el primer número: ");
                    num2 = ingresarNumero(sc, "Ingrese el segundo número: ");
                    resultado = sumar(num1, num2);
                    System.out.println(num1 + " + " + num2 + " = " + resultado);
                    break;

                case 2:
                    System.out.println("\nRESTA\n");
                    num1 = ingresarNumero(sc, "Ingrese el primer número: ");
                    num2 = ingresarNumero(sc, "Ingrese el segundo número: ");
                    resultado = restar(num1, num2);
                    System.out.println(num1 + " - " + num2 + " = " + resultado);
                    break;

                case 3:
                    System.out.println("\nMULTIPLICACIÓN\n");
                    num1 = ingresarNumero(sc, "Ingrese el primer número: ");
                    num2 = ingresarNumero(sc, "Ingrese el segundo número: ");
                    resultado = multiplicar(num1, num2);
                    System.out.println(num1 + " * " + num2 + " = " + resultado);
                    break;

                case 4:
                    System.out.println("\nDIVISIÓN\n");
                    num1 = ingresarNumero(sc, "Ingrese el primer número: ");
                    num2 = ingresarNumero(sc, "Ingrese el segundo número: ");
                    if (num2 == 0) {
                        System.out.println("No se puede dividir por cero.");
                    } else {
                        resultado = dividir(num1, num2);
                        System.out.println(num1 + " / " + num2 + " = " + resultado);
                    }
                    break;

                case 5:
                    System.out.println("\nSALIR\n");
                    break;

                default:
                    System.out.println("\nOPCIÓN INVÁLIDA\n");
                    break;
            }
        } while (opcion != 5);
        sc.close();
    }

    public static double ingresarNumero(Scanner sc, String mensaje) {
        System.out.print(mensaje);
        double num = sc.nextDouble();
        return num;
    }

    public static double sumar(double num1, double num2) {
        double resultado = num1 + num2;
        return resultado;
    }

    public static double restar(double num1, double num2) {
        double resultado = num1 - num2;
        return resultado;
    }

    public static double multiplicar(double num1, double num2) {
        double resultado = num1 * num2;
        return resultado;
    }

    public static double dividir(double num1, double num2) {
        double resultado = num1 / num2;
        return resultado;
    }
}